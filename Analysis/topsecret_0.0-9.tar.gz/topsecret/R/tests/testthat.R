library(testthat)
library(helloJavaWorld)

test_check("helloJavaWorld")
