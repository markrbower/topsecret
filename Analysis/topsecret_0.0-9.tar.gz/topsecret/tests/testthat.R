library(testthat)
library(topsecret)

test_check("topsecret")
